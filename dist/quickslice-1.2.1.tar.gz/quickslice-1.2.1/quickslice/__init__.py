def info():
    print('The core module contains core functionality like build and slice')
